({
	loadingState: "Carregando...",
	errorState: "Ocorreu um erro"
})
