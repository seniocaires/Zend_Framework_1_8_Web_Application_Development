// generated from ldml/main/*.xml, xpath: ldml/calendars/calendar-gregorian
({
	'timeFormat-full': "HH'H'mm''ss\" v",
	'timeFormat-medium': "H:mm:ss",
	'timeFormat-short': "H:mm"
})
                        