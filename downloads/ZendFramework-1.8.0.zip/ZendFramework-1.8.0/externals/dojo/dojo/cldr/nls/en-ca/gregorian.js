({
	"dateFormat-medium": "yyyy-MM-dd", 
	"dateTimeAvailableFormats": [
		"MM-dd", 
		"MMM-yy", 
		"L", 
		"E, M/d", 
		"LLL", 
		"E, MMM d", 
		"E, MMMM d", 
		"MMMM d", 
		"MMM d", 
		"M/d", 
		"d", 
		"h:mm a", 
		"mm:ss", 
		"yyyy", 
		"M/yyyy", 
		"EEE, M/d/yyyy", 
		"MMM yyyy", 
		"EEE, MMM d, yyyy", 
		"MMMM yyyy", 
		"Q yyyy", 
		"QQQ yyyy"
	], 
	"dateFormat-short": "yy-MM-dd"
})