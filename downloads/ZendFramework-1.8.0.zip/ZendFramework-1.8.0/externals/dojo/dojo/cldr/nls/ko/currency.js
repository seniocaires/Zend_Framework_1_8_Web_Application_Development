// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"호주 달러",
	AUD_symbol:"A$",
	CAD_displayName:"캐나다 달러",
	CAD_symbol:"Can$",
	CHF_displayName:"스위스 프랑",
	CNY_displayName:"중국 위안 인민폐",
	CNY_symbol:"¥",
	EUR_displayName:"유로화",
	GBP_displayName:"영국령 파운드 스털링",
	HKD_displayName:"홍콩 달러",
	HKD_symbol:"HK$",
	JPY_displayName:"일본 엔",
	JPY_symbol:"￥",
	USD_displayName:"미국 달러"
})
                 