// generated from ldml/main/*.xml, xpath: ldml/calendars/calendar-gregorian
({
        'timeFormat-long': "H:mm:ss z"
})
                        