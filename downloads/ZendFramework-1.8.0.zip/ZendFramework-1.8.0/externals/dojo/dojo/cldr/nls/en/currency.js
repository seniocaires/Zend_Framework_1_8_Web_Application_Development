// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"Australian Dollar",
	AUD_symbol:"A$",
	CAD_displayName:"Canadian Dollar",
	CAD_symbol:"CA$",
	CHF_displayName:"Swiss Franc",
	CHF_symbol:"Fr.",
	CNY_displayName:"Chinese Yuan Renminbi",
	CNY_symbol:"RMB",
	EUR_displayName:"Euro",
	GBP_displayName:"British Pound Sterling",
	GBP_symbol:"£",
	HKD_displayName:"Hong Kong Dollar",
	HKD_symbol:"HK$",
	JPY_displayName:"Japanese Yen",
	JPY_symbol:"¥",
	USD_displayName:"US Dollar",
	USD_symbol:"$"
})
                 