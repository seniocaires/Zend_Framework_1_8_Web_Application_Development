// generated from ldml/main/*.xml, xpath: ldml/numbers
({
        'currencyFormat':"¤#,##0.00;(¤#,##0.00)"
})
