// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"Australischer Dollar",
	AUD_symbol:"$A",
	CAD_displayName:"Kanadischer Dollar",
	CAD_symbol:"Can$",
	CHF_displayName:"Schweizer Franken",
	CHF_symbol:"SFr.",
	CNY_displayName:"Renminbi Yuan",
	CNY_symbol:"Y",
	EUR_displayName:"Euro",
	GBP_displayName:"Pfund Sterling",
	GBP_symbol:"£",
	HKD_displayName:"Hongkong-Dollar",
	JPY_displayName:"Yen",
	JPY_symbol:"¥",
	USD_displayName:"US-Dollar",
	USD_symbol:"$"
})
                 