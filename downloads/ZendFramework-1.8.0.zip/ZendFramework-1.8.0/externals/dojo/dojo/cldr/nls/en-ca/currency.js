// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	CAD_symbol:"$",
	USD_symbol:"US$"
})
                 