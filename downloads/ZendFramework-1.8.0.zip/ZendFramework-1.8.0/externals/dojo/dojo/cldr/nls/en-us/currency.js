// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	USD_symbol:"$"
})
                 