// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"Dólar australiano",
	AUD_symbol:"$A",
	CAD_displayName:"Dólar canadense",
	CAD_symbol:"Can$",
	CHF_displayName:"Franco suíço",
	CHF_symbol:"SwF",
	CNY_displayName:"Yuan Renminbi chinês",
	CNY_symbol:"Y",
	EUR_displayName:"Euro",
	GBP_displayName:"Libra esterlina britânica",
	GBP_symbol:"£",
	HKD_displayName:"Dólar de Hong Kong",
	HKD_symbol:"HK$",
	JPY_displayName:"Iene japonês",
	JPY_symbol:"¥",
	USD_displayName:"Dólar norte-americano"
})
                 