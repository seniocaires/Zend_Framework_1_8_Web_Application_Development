// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	EUR_displayName:"EUR",
	EUR_symbol:"€",
	GBP_displayName:"GBP",
	GBP_symbol:"UK£",
	JPY_displayName:"JPY",
	JPY_symbol:"JP¥",
	USD_displayName:"USD",
	USD_symbol:"US$"
})
                 