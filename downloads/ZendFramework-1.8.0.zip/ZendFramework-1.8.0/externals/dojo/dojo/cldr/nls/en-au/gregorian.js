({
	"dateTimeAvailableFormats": [
		"d MMMM", 
		"dd/MM", 
		"MM/yyyy", 
		"MMMM yyyy", 
		"LLL", 
		"E, MMM d", 
		"E, MMMM d", 
		"MMMM d", 
		"MMM d", 
		"M/d", 
		"d", 
		"h:mm a", 
		"mm:ss", 
		"yyyy", 
		"M/yyyy", 
		"EEE, M/d/yyyy", 
		"MMM yyyy", 
		"EEE, MMM d, yyyy", 
		"MMMM yyyy", 
		"Q yyyy", 
		"QQQ yyyy"
	], 
	"dateFormat-short": "d/MM/yy", 
	"dateFormat-medium": "dd/MM/yyyy", 
	"dateFormat-long": "d MMMM yyyy", 
	"dateFormat-full": "EEEE, d MMMM yyyy"
})