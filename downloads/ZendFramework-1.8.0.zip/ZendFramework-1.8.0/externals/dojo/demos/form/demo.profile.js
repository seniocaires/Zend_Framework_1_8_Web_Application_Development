dependencies = {
	layers: [
		{
			name: "../demos/form/src.js",
			resourceName: "demos.form.src",
			dependencies: [
				"demos.form.src"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ],
		[ "demos", "../demos" ]
	]
}
