dojo.provide("demos.fonts.src");

dojo.require("dojox.gfx");
dojo.require("dojox.gfx.VectorText");
