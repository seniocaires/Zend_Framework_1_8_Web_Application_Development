dependencies = {
	layers: [
		{
			name: "../demos/i18n/src.js",
			resourceName: "demos.i18n.src",
			dependencies: [
				"demos.i18n.src"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ],
		[ "demos", "../demos" ]
	]
}
