dependencies = {
	layers: [
		{
			name: "../demos/skew/src.js",
			resourceName: "demos.skew.src",
			dependencies: [
				"demos.skew.src"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ],
		[ "demos", "../demos" ]
	]
}
