dependencies = {
	layers: [
		{
			name: "../demos/flashCards/src.js",
			resourceName: "demos.flashCards.src",
			dependencies: [
				"demos.flashCards.src"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ],
		[ "demos", "../demos" ]
	]
}
