dependencies = {
	layers: [
		{
			name: "../demos/video/src.js",
			resourceName: "demos.video.src",
			dependencies: [
				"demos.video.src"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ],
		[ "demos", "../demos" ]
	]
}
