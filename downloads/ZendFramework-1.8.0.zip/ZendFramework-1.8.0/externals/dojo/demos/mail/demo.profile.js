dependencies = {
	layers: [
		{
			name: "../demos/mail/src.js",
			resourceName: "demos.mail.src",
			dependencies: [
				"demos.mail.src"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ],
		[ "demos", "../demos" ]
	]
}
