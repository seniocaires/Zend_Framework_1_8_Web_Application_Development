dependencies = {
	layers: [
		{
			name: "../demos/uploader/src.js",
			resourceName: "demos.uploader.src",
			dependencies: [
				"demos.uploader.src"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ],
		[ "demos", "../demos" ]
	]
}
