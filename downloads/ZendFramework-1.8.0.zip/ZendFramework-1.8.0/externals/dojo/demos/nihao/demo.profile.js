dependencies = {
	layers: [
		{
			name: "../demos/nihao/src.js",
			resourceName: "demos.nihao.src",
			dependencies: [
				"demos.nihao.src"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ],
		[ "demos", "../demos" ]
	]
}
