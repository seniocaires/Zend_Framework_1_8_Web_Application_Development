({
	"localeSelect": "区域：",
	"contentStr": "你好Dojo全球化! 今天是${0}。",
	"dateSelect": "选择一个日期：",
	"dateStr": "距离现在还有${0}秒。"
})