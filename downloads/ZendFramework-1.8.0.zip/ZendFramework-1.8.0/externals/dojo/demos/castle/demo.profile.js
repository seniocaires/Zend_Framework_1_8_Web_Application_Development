dependencies = {
	layers: [
		{
			name: "../demos/castle/src.js",
			resourceName: "demos.castle.src",
			dependencies: [
				"demos.castle.src"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ],
		[ "demos", "../demos" ]
	]
}
