dependencies = {
	layers: [
		{
			name: "../demos/mojo/src.js",
			dependencies: [
				"demos.mojo.src"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ],
		[ "demos", "../demos" ]
	]
}
